ENERGY CONSUMPTION AND SUSTAINABILITY ANALYTICS — AUTOMATIC DATA LOADING

This version loads household_power_consumption.txt.zip automatically when the app opens. Uploading another dataset is optional.

Files that must be in the same GitHub repository folder:
- app.py
- requirements.txt
- household_power_consumption.txt.zip

Deploy/update steps:
1. Open https://github.com/ameesatsangi/energy-consumption-dashboard
2. Upload or replace app.py and requirements.txt in the repository root.
3. Upload household_power_consumption.txt.zip to the same repository root.
4. Commit the changes.
5. Open the Streamlit Community Cloud app settings and confirm the app entrypoint is app.py in the repository root. If needed, reboot the app.
6. Reopen the dashboard. It should load the included dataset automatically. The uploader remains available only if you want to use a different dataset.

The dataset file is approximately 20 MB and is below GitHub's 100 MB per-file limit. Do not rename the dataset unless you also update DATASET_PATH in app.py.

The app analyses December 2009 through November 2010. The source data ends on 26 November 2010, so November is incomplete. Monthly energy values are estimates and may be lower than actual use due to missing readings. The data represents one household in France.
